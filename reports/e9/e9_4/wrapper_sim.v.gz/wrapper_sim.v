// P2R-E8.7 wrapper (written by scripts/e8_7_tools.py core): module amu9_top = the synthesised
// logic (amu9_top_core, instance core) + the simulation models of the 7 memory macros it connects to.
// The parameters of every macro are those of the synthesised netlist, except DATA_DIR and COMMON_DIR,
// which come from this module (the testbench sets them for the model).
`timescale 1ns/1ps
module amu9_top(clk, rst_n, layer_id, orig_addr_bus, start_req, sram_base, sram_size, pcm_base, pcm_size, sram_hit, sram_oor, sram_pool_addr_bus, pcm_hit, pcm_oor, pcm_pool_addr_bus, start_go, stall, n_lookup_reads, n_park_reads, n_stall_cycles, n_starts, errors);
    parameter DATA_DIR = "";
    parameter COMMON_DIR = "";
    parameter K = 0;
    parameter ADDR_WIDTH = 0;
    parameter SRAM_TOTAL = 0;
    parameter PCM_TOTAL = 0;
    input clk;
    wire clk;
    input rst_n;
    wire rst_n;
    input [2:0] layer_id;
    wire [2:0] layer_id;
    input [399:0] orig_addr_bus;
    wire [399:0] orig_addr_bus;
    input start_req;
    wire start_req;
    input [15:0] sram_base;
    wire [15:0] sram_base;
    input [15:0] sram_size;
    wire [15:0] sram_size;
    input [15:0] pcm_base;
    wire [15:0] pcm_base;
    input [15:0] pcm_size;
    wire [15:0] pcm_size;
    output [24:0] sram_hit;
    wire [24:0] sram_hit;
    output [24:0] sram_oor;
    wire [24:0] sram_oor;
    output [399:0] sram_pool_addr_bus;
    wire [399:0] sram_pool_addr_bus;
    output [24:0] pcm_hit;
    wire [24:0] pcm_hit;
    output [24:0] pcm_oor;
    wire [24:0] pcm_oor;
    output [399:0] pcm_pool_addr_bus;
    wire [399:0] pcm_pool_addr_bus;
    output start_go;
    wire start_go;
    output stall;
    wire stall;
    output [31:0] n_lookup_reads;
    wire [31:0] n_lookup_reads;
    output [31:0] n_park_reads;
    wire [31:0] n_park_reads;
    output [31:0] n_stall_cycles;
    wire [31:0] n_stall_cycles;
    output [31:0] n_starts;
    wire [31:0] n_starts;
    output [2:0] errors;
    wire [2:0] errors;
    wire bb0000_clk0;
    wire bb0000_cs0;
    wire [8:0] bb0000_addr0;
    wire [39:0] bb0000_dout0;
    wire bb0001_clk0;
    wire bb0001_cs0;
    wire [8:0] bb0001_addr0;
    wire [39:0] bb0001_dout0;
    wire bb0002_clk0;
    wire bb0002_cs0;
    wire [8:0] bb0002_addr0;
    wire [39:0] bb0002_dout0;
    wire bb0003_clk0;
    wire bb0003_cs0;
    wire [8:0] bb0003_addr0;
    wire [39:0] bb0003_dout0;
    wire bb0004_clk0;
    wire bb0004_cs0;
    wire [8:0] bb0004_addr0;
    wire [39:0] bb0004_dout0;
    wire bb0005_clk0;
    wire bb0005_cs0;
    wire [8:0] bb0005_addr0;
    wire [39:0] bb0005_dout0;
    wire bb0006_clk0;
    wire bb0006_cs0;
    wire [8:0] bb0006_addr0;
    wire [39:0] bb0006_dout0;
    amu9_top_core core (
        .clk(clk),
        .rst_n(rst_n),
        .layer_id(layer_id),
        .orig_addr_bus(orig_addr_bus),
        .start_req(start_req),
        .sram_base(sram_base),
        .sram_size(sram_size),
        .pcm_base(pcm_base),
        .pcm_size(pcm_size),
        .sram_hit(sram_hit),
        .sram_oor(sram_oor),
        .sram_pool_addr_bus(sram_pool_addr_bus),
        .pcm_hit(pcm_hit),
        .pcm_oor(pcm_oor),
        .pcm_pool_addr_bus(pcm_pool_addr_bus),
        .start_go(start_go),
        .stall(stall),
        .n_lookup_reads(n_lookup_reads),
        .n_park_reads(n_park_reads),
        .n_stall_cycles(n_stall_cycles),
        .n_starts(n_starts),
        .errors(errors),
        .bb0000_clk0(bb0000_clk0),
        .bb0000_cs0(bb0000_cs0),
        .bb0000_addr0(bb0000_addr0),
        .bb0000_dout0(bb0000_dout0),
        .bb0001_clk0(bb0001_clk0),
        .bb0001_cs0(bb0001_cs0),
        .bb0001_addr0(bb0001_addr0),
        .bb0001_dout0(bb0001_dout0),
        .bb0002_clk0(bb0002_clk0),
        .bb0002_cs0(bb0002_cs0),
        .bb0002_addr0(bb0002_addr0),
        .bb0002_dout0(bb0002_dout0),
        .bb0003_clk0(bb0003_clk0),
        .bb0003_cs0(bb0003_cs0),
        .bb0003_addr0(bb0003_addr0),
        .bb0003_dout0(bb0003_dout0),
        .bb0004_clk0(bb0004_clk0),
        .bb0004_cs0(bb0004_cs0),
        .bb0004_addr0(bb0004_addr0),
        .bb0004_dout0(bb0004_dout0),
        .bb0005_clk0(bb0005_clk0),
        .bb0005_cs0(bb0005_cs0),
        .bb0005_addr0(bb0005_addr0),
        .bb0005_dout0(bb0005_dout0),
        .bb0006_clk0(bb0006_clk0),
        .bb0006_cs0(bb0006_cs0),
        .bb0006_addr0(bb0006_addr0),
        .bb0006_dout0(bb0006_dout0)
    );
    // mac[0].U_ROM
    e9_rom #(.MACRO(32'sd0)) bb0000 (.clk0(bb0000_clk0), .cs0(bb0000_cs0), .addr0(bb0000_addr0), .dout0(bb0000_dout0));
    // mac[1].U_ROM
    e9_rom #(.MACRO(32'sd1)) bb0001 (.clk0(bb0001_clk0), .cs0(bb0001_cs0), .addr0(bb0001_addr0), .dout0(bb0001_dout0));
    // mac[2].U_ROM
    e9_rom #(.MACRO(32'sd2)) bb0002 (.clk0(bb0002_clk0), .cs0(bb0002_cs0), .addr0(bb0002_addr0), .dout0(bb0002_dout0));
    // mac[3].U_ROM
    e9_rom #(.MACRO(32'sd3)) bb0003 (.clk0(bb0003_clk0), .cs0(bb0003_cs0), .addr0(bb0003_addr0), .dout0(bb0003_dout0));
    // mac[4].U_ROM
    e9_rom #(.MACRO(32'sd4)) bb0004 (.clk0(bb0004_clk0), .cs0(bb0004_cs0), .addr0(bb0004_addr0), .dout0(bb0004_dout0));
    // mac[5].U_ROM
    e9_rom #(.MACRO(32'sd5)) bb0005 (.clk0(bb0005_clk0), .cs0(bb0005_cs0), .addr0(bb0005_addr0), .dout0(bb0005_dout0));
    // mac[6].U_ROM
    e9_rom #(.MACRO(32'sd6)) bb0006 (.clk0(bb0006_clk0), .cs0(bb0006_cs0), .addr0(bb0006_addr0), .dout0(bb0006_dout0));
    // ---- P2R-E9.4, simulation only (scripts/e9_4_tools.py wrapper) ----
    // The read pulses of the 7 ROM models in the format of the event list of E9.1
    // (rtl/e9/tb/e9_1_amu_monitor.v) without its entry and buffer-slot columns, which are internal to
    // the logic netlist; with +e9_events=<file>. A parking read is a read of address 383 (the lookups
    // read addresses 0..382). Sampled at the falling clock edge, as the E9.1 monitor does:
    //   L <phase> <cycle_after_start> <macro> <address, 3 hex digits> <clock-low cycles before the read>
    //   P <phase> <cycle_after_start> <macro> <clock-low cycles before the read>
    // (phase B before the start, I during the inference, A after done). At the end it prints the
    // "E9.4 ROM" line: the pulses, and the reads and protocol errors counted by the 7 models.
    reg  [8*512-1:0] e94_fn;
    integer e94_fd = 0, e94_cyc = 0, e94_low, e94_k, e94_nl = 0, e94_np = 0;
    integer e94_lf [0:6];
    reg  [6:0] e94_q = 7'd0;
    reg  e94_done = 1'b0;
    reg  [7:0] e94_ph;
    wire [6:0] e94_clk = {bb0006_clk0, bb0005_clk0, bb0004_clk0, bb0003_clk0, bb0002_clk0, bb0001_clk0, bb0000_clk0};
    wire [8:0] e94_a [0:6];
    assign e94_a[0] = bb0000_addr0;   // mac[0].U_ROM, bb0000
    assign e94_a[1] = bb0001_addr0;   // mac[1].U_ROM, bb0001
    assign e94_a[2] = bb0002_addr0;   // mac[2].U_ROM, bb0002
    assign e94_a[3] = bb0003_addr0;   // mac[3].U_ROM, bb0003
    assign e94_a[4] = bb0004_addr0;   // mac[4].U_ROM, bb0004
    assign e94_a[5] = bb0005_addr0;   // mac[5].U_ROM, bb0005
    assign e94_a[6] = bb0006_addr0;   // mac[6].U_ROM, bb0006
    initial begin
        for (e94_k = 0; e94_k < 7; e94_k = e94_k + 1) e94_lf[e94_k] = -1;
        if ($value$plusargs("e9_events=%s", e94_fn)) begin
            e94_fd = $fopen(e94_fn, "w");
            $fdisplay(e94_fd, "# P2R-E9.4 ROM clock pulses of the synthesised address-map unit (gate level)");
            $fdisplay(e94_fd, "# L phase cycle macro addr_hex low_cycles   (lookup read)");
            $fdisplay(e94_fd, "# P phase cycle macro low_cycles            (parking read of address 383)");
        end
    end
    always @(negedge clk) begin
        e94_cyc = e94_cyc + 1;
        if (tb_lenet5_full_inference_v3.done_seen) e94_done = 1'b1;
        e94_ph = !tb_lenet5_full_inference_v3.started_flag ? "B" : (e94_done ? "A" : "I");
        for (e94_k = 0; e94_k < 7; e94_k = e94_k + 1) begin
            if (e94_clk[e94_k] && !e94_q[e94_k]) begin
                e94_low = (e94_lf[e94_k] < 0) ? 99999 : e94_cyc - e94_lf[e94_k];
                if (e94_a[e94_k] == 9'd383) begin
                    if (e94_fd) $fwrite(e94_fd, "P %0s %0d %0d %0d\n", e94_ph, tb_lenet5_full_inference_v3.cycle_after_start, e94_k, e94_low);
                    e94_np = e94_np + 1;
                end else begin
                    if (e94_fd) $fwrite(e94_fd, "L %0s %0d %0d %03h %0d\n", e94_ph, tb_lenet5_full_inference_v3.cycle_after_start, e94_k,
                                        e94_a[e94_k], e94_low);
                    e94_nl = e94_nl + 1;
                end
            end
            if (!e94_clk[e94_k] && e94_q[e94_k]) e94_lf[e94_k] = e94_cyc;
        end
        e94_q = e94_clk;
    end
    real e94_lmin;
    final begin
        if (e94_fd) $fclose(e94_fd);
        e94_lmin = 1.0e9;
        if (bb0000.n_reads != 0 && bb0000.low_min < e94_lmin) e94_lmin = bb0000.low_min;
        if (bb0001.n_reads != 0 && bb0001.low_min < e94_lmin) e94_lmin = bb0001.low_min;
        if (bb0002.n_reads != 0 && bb0002.low_min < e94_lmin) e94_lmin = bb0002.low_min;
        if (bb0003.n_reads != 0 && bb0003.low_min < e94_lmin) e94_lmin = bb0003.low_min;
        if (bb0004.n_reads != 0 && bb0004.low_min < e94_lmin) e94_lmin = bb0004.low_min;
        if (bb0005.n_reads != 0 && bb0005.low_min < e94_lmin) e94_lmin = bb0005.low_min;
        if (bb0006.n_reads != 0 && bb0006.low_min < e94_lmin) e94_lmin = bb0006.low_min;
        $display("E9.4 ROM: lookup pulses %0d, parking pulses %0d; model reads %0d, parking word %0d; protocol errors: CS at the clock edge %0d, address changed while high %0d, invalid word %0d; shortest clock low before a read %0.1f ns",
                 e94_nl, e94_np, bb0000.n_reads + bb0001.n_reads + bb0002.n_reads + bb0003.n_reads + bb0004.n_reads + bb0005.n_reads + bb0006.n_reads, bb0000.n_park_reads + bb0001.n_park_reads + bb0002.n_park_reads + bb0003.n_park_reads + bb0004.n_park_reads + bb0005.n_park_reads + bb0006.n_park_reads,
                 bb0000.n_err_cs + bb0001.n_err_cs + bb0002.n_err_cs + bb0003.n_err_cs + bb0004.n_err_cs + bb0005.n_err_cs + bb0006.n_err_cs, bb0000.n_err_addr + bb0001.n_err_addr + bb0002.n_err_addr + bb0003.n_err_addr + bb0004.n_err_addr + bb0005.n_err_addr + bb0006.n_err_addr, bb0000.n_err_word + bb0001.n_err_word + bb0002.n_err_word + bb0003.n_err_word + bb0004.n_err_word + bb0005.n_err_word + bb0006.n_err_word, e94_lmin);
    end
endmodule
